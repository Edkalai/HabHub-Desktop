/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MailAPI;

/**
 *
 * @author NADA_USER
 */
public class MainMail {
    public static void main(String[] args) throws Exception {
       JavaMailUtil.sendMail("nadounouissee@gmail.com");
        
        
        }
    
}
